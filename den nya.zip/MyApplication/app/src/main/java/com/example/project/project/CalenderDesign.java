package com.example.project.project;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextSwitcher;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewSwitcher;

import java.util.Calendar;

public class CalenderDesign extends DialogFragment implements ViewSwitcher.ViewFactory{

    String dateString;

    private ImageView plus_a_year, minus_a_year, plus_a_month, minus_a_month, plus_a_day, minus_a_day;
    private TextSwitcher yearSwitcher, monthSwitcher, daySwitcher;

    String[] months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};

    private Listener mListener;

    private int prevMonth;
    private Calendar cal;

    public CalenderDesign() {
        // Empty constructor required for DialogFragment
    }

    public static CalenderDesign newInstance(Button btnDate){
        CalenderDesign fragment = new CalenderDesign();

        //Make button to argument if you want input
        Bundle args = new Bundle();
        args.putString("date", btnDate.getText().toString());
        fragment.setArguments(args);
        return fragment;
    }

    public void setListener(Listener listener) {
        mListener = listener;
    }

    static interface Listener {
        void returnData(String result);
    }

    public interface CalenderDesignReturn {
        void onFinishEditDialog(String inputText);
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {


        // Use the Builder class for convenient dialog construction
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();
        final View view = inflater.inflate(R.layout.custom_date_picker, null);
        final View mainView = inflater.inflate(R.layout.custom_row_view, null);

        dateString = getArguments().getString("date");
        builder.setView(view)
                .setPositiveButton("ADD DATE", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        updateSwitcher();
//                        int month = cal.get(Calendar.MONTH) + 1;
//                        Toast.makeText(
//                                getActivity(),
//                                cal.get(Calendar.YEAR) + "-" + month
//                                        + "-" + cal.get(Calendar.DAY_OF_MONTH),
//                                Toast.LENGTH_LONG).show();

                        int Year = cal.get(Calendar.YEAR);
                        int Month = cal.get(Calendar.MONTH) + 1;
                        int Day = cal.get(Calendar.DAY_OF_MONTH);


                        //casting it to string
                        String time = Integer.toString(Year) + "-" + Integer.toString(Month) + "-" + Integer.toString(Day);

                        Log.d("log tid", ""+time);
                      //  mListener.returnData(time);

                        CalenderDesignReturn activity = (CalenderDesignReturn) getActivity();
                        activity.onFinishEditDialog(time);

//                        Button dateBtn = (Button)mainView.findViewById(R.id.dateBtn);
//                        dateBtn.setText(time);

                        //fixBtn.setText(Year + "-" + Month + "-" + Day);

                    }
                })

                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // User cancelled the dialog
                    }
                });



        yearSwitcher = (TextSwitcher) view.findViewById(R.id.YearSwitcher);
        //ViewSwitcher
        yearSwitcher.setFactory(this);

        monthSwitcher = (TextSwitcher) view.findViewById(R.id.MonthSwitcher);
        //ViewSwitcher
        monthSwitcher.setFactory(this);

        daySwitcher = (TextSwitcher) view.findViewById(R.id.DaySwitcher);
        //ViewSwitcher
        daySwitcher.setFactory(this);

        //getting the images
        plus_a_year = (ImageView) view.findViewById(R.id.plus_a_year);
        minus_a_year = (ImageView) view.findViewById(R.id.minus_a_year);

        plus_a_month = (ImageView) view.findViewById(R.id.plus_a_month);
        minus_a_month = (ImageView) view.findViewById(R.id.minus_a_month);

        plus_a_day = (ImageView) view.findViewById(R.id.plus_a_day);
        minus_a_day = (ImageView) view.findViewById(R.id.minus_a_day);



        cal = Calendar.getInstance();
        getClickEvents(plus_a_year, Calendar.YEAR, 1);
        getClickEvents(minus_a_year, Calendar.YEAR, -1);
        getClickEvents(plus_a_month, Calendar.MONTH, 1);
        getClickEvents(minus_a_month, Calendar.MONTH, -1);
        getClickEvents(plus_a_day, Calendar.DAY_OF_YEAR, 1);
        getClickEvents(minus_a_day, Calendar.DAY_OF_YEAR, -1);


        updateSwitcher();


        return builder.create();

    }

    //this is for ViewSwitcher
    public View makeView() {
        TextView t = new TextView(getActivity());
        t.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        t.setTextAppearance(getActivity(), R.style.AppTheme);

        return t;
    }

    private void getClickEvents(ImageView imageView, final int field,
                                final int value) {

        imageView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                cal.roll(field, value);
                updateSwitcher();
            }
        });
    }

    public void updateSwitcher() {
        yearSwitcher.setText(String.valueOf(cal.get(Calendar.YEAR)));
        monthSwitcher.setText(monthNames(cal.get(Calendar.MONTH)));
        daySwitcher.setText(String.valueOf(cal.get(Calendar.DAY_OF_MONTH)));

    }

    // KOMPLETTERING
    //gjort om det från if statement så att man kan använda en array istället

    public void setMonthNames(String[] newNames){
        this.months = newNames;
    }

    public String monthNames(int value){

        for(int i = 0; i<months.length; i++){

            if(i == value){
                return months[i];
            }
        }
        return null;
    }

}